from setuptools import setup

setup(name='nitin_probability_distribution',
      version="1.2", 
        description='Gaussian and Binomial distributions',
        packages=['nitin_probability_distribution'],
        author='Nitin Soni',
        author_email='yonitinsoni@gmail.com', 
    zip_safe=False)


